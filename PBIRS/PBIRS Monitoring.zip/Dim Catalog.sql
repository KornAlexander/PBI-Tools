SELECT C.[ItemID]
      ,C.[Path]
      ,C.[Name]
      ,C.[ParentID]
      ,C.[Type]
	                       ,CASE c.[Type]
                                  WHEN 1 THEN 'Folder'
                                  WHEN 2 THEN 'Report'
                                  WHEN 3 THEN 'Resources'
                                  WHEN 4 THEN 'Linked Report'
                                  WHEN 5 THEN 'Data Source'
                                  WHEN 6 THEN 'Report Model'
                                  WHEN 7 THEN 'Report Part'
                                  WHEN 8 THEN 'Shared dataset'
                                  WHEN 11 THEN 'KPI Card'
                                  WHEN 13 THEN 'PowerBI'
                                  ELSE CAST(c.[Type] AS VARCHAR(10))
                           END AS ItemType
      ,C.[Content]
      ,C.[Intermediate]
      ,C.[SnapshotDataID]
      ,C.[LinkSourceID]
      ,C.[Property]
      ,C.[Description]
      ,C.[Hidden]
      ,C.[CreatedByID]
      ,C.[CreationDate]
      ,C.[ModifiedByID]
      ,C.[ModifiedDate]
      ,C.[MimeType]
      ,C.[SnapshotLimit]
      ,C.[Parameter]
      ,C.[PolicyID]
      ,C.[PolicyRoot]
      ,C.[ExecutionFlag]
      ,C.[ExecutionTime]
      ,C.[SubType]
      ,C.[ComponentID]
      ,C.[ContentSize]
	  ,cu.UserName AS CreatedUserName
      ,mu.UserName AS ModifiedUserName
	  ,CASE c.PolicyRoot
               WHEN 0 THEN 'No'
			   WHEN 1 THEN 'Yes'
               ELSE CAST(c.PolicyRoot AS VARCHAR(10))
       END AS 'IsCustomizedItemSecurity'
	   --,R.RoleName
	   --,PU.UserName AS FolderAccessUsers --For getting each assigned user with access
  FROM [dbo].[Catalog] C
	LEFT JOIN   dbo.Users cu ON c.CreatedByID = cu.UserID
	LEFT JOIN   dbo.Users mu ON c.ModifiedByID = mu.UserID
    --LEFT JOIN	dbo.PolicyUserRole PUR ON c.PolicyID = PUR.PolicyID
	--LEFT JOIN dbo.Users PU ON C.ModifiedByID = PUR.UserID --For getting each assigned user with access
	--LEFT JOIN	dbo.Roles R ON PUR.RoleID = R.RoleID
	--Where PolicyRoot = '1' --Customized Security