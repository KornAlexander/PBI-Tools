--Check backlog
--table has lots of rows therefore refresh backlog is big
--table has no rows therefore no backlog
SELECT * FROM [dbo].[Event]