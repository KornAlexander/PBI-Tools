SELECT
ReportID = CAT.ItemID
,PowerBIReportName = CAT.[Name]
,ReportPath = CAT.[Path]
,DMS.DataModelMBs
,DS.DSType
,DSKind
,DS.AuthType
,HasEmbeddedModels = CAST([Property] as xml).value('(/Properties/HasEmbeddedModels)[1]','nvarchar(max)')
,PbixShredderVersion = CAST([Property] as xml).value('(/Properties/PbixShredderVersion)[1]','nvarchar(max)')
,ModelRefreshAllowed = CAST([Property] as xml).value('(/Properties/ModelRefreshAllowed)[1]','nvarchar(max)')
,HasDirectQuery = CAST([Property] as xml).value('(/Properties/HasDirectQuery)[1]','nvarchar(max)')
,ModelVersion = CAST([Property] as xml).value('(/Properties/ModelVersion)[1]','nvarchar(max)')
,CAT.[Parameter]
FROM [Catalog] CAT
LEFT OUTER JOIN DataModelDataSource DS
ON DS.ItemID = CAT.ItemID
LEFT OUTER JOIN
(SELECT
C.ContentType
,C.Id
,C.ItemId
,DataModelMBs = DATALENGTH(Content)/1048576
FROM CatalogItemExtendedContent C
WHERE C.ContentType = 'DataModel') DMS
ON DMS.ItemId = CAT.ItemID
WHERE [Type] = 13;